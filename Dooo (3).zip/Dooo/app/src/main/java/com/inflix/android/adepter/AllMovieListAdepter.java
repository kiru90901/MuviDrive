package com.inflix.android.adepter;


import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.inflix.android.AppConfig;
import com.inflix.android.MovieDetails;
import com.inflix.android.R;
import com.inflix.android.list.MovieList;
import com.inflix.android.utils.Utils;

import java.util.List;

public class AllMovieListAdepter extends RecyclerView.Adapter<AllMovieListAdepter.MyViewHolder> {

    private Context mContext;
    private List<MovieList> mData;

    Context context;

    public AllMovieListAdepter(Context mContext, List<MovieList> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public int getItemViewType(int position) {
        return AppConfig.contentItem;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View  view = LayoutInflater.from(parent.getContext()).inflate(AppConfig.contentItem, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.setTitle(mData.get(position));
        holder.setYear(mData.get(position));
        holder.setImage(mData.get(position));
        holder.IsPremium(mData.get(position));
        holder.setCustomTag(mData.get(position));

        holder.Movie_Item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, MovieDetails.class);
                intent.putExtra("ID", mData.get(position).getID());
                mContext.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setMovieList(List<MovieList> newList) {
        mData.clear();
        mData.addAll(newList);
        this.notifyDataSetChanged();
    }

    public void addMovieList(List<MovieList> newList) {
        int startPosition = mData.size();
        mData.addAll(newList);
        this.notifyItemRangeInserted(startPosition, newList.size());
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView Title;
        TextView Year;
        ImageView Thumbnail;
        View Premium_Tag;
        CardView Movie_Item;
        CardView tag_card;
        TextView tag_text;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            Title = (TextView) itemView.findViewById(R.id.Movie_list_Title);
            Year = (TextView) itemView.findViewById(R.id.Movie_list_Year);
            Thumbnail = (ImageView) itemView.findViewById(R.id.Movie_Item_thumbnail);
            Premium_Tag = (View) itemView.findViewById(R.id.Premium_Tag);
            Movie_Item = itemView.findViewById(R.id.Movie_Item);
            tag_card = itemView.findViewById(R.id.tag_card);
            tag_text = itemView.findViewById(R.id.tag_text);
        }

        void IsPremium(MovieList type) {
            if(AppConfig.all_movies_type == 0) {
                if(type.getType() == 1) {
                    Premium_Tag.setVisibility(View.VISIBLE);
                } else {
                    Premium_Tag.setVisibility(View.GONE);
                }
            } else if(AppConfig.all_movies_type == 1) {
                Premium_Tag.setVisibility(View.GONE);
            } else if(AppConfig.all_movies_type == 2) {
                Premium_Tag.setVisibility(View.VISIBLE);
            }
        }

        void setTitle(MovieList title_text) {
            Title.setText(title_text.getTitle());
        }

        void setYear(MovieList year_text) {
            Year.setText(year_text.getYear());
        }

        void setImage(MovieList Thumbnail_Image) {
            if(AppConfig.safeMode) {
                Glide.with(context)
                        .load(R.drawable.thumbnail_placeholder)
                        .placeholder(R.drawable.thumbnail_placeholder)
                        .into(Thumbnail);
            } else {

                if(AppConfig.isProxyImages) {
                    Glide.with(context)
                            .load(AppConfig.url+"/imageProxy/"+ Utils.urlEncode(Utils.toBase64(Thumbnail_Image.getThumbnail())))
                            .placeholder(R.drawable.thumbnail_placeholder)
                            .into(Thumbnail);
                } else {
                    Glide.with(context)
                            .load(Thumbnail_Image.getThumbnail())
                            .placeholder(R.drawable.thumbnail_placeholder)
                            .into(Thumbnail);
                }

            }
        }

        void setCustomTag(MovieList movieList) {
            if (!movieList.getCustom_tag().isEmpty()) {
                tag_text.setText(movieList.getCustom_tag());
                tag_card.setVisibility(View.VISIBLE);
                tag_text.setTextColor(Color.parseColor(movieList.getCustom_tag_text_color()));
                tag_card.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(movieList.getCustom_tag_background_color())));
            } else {
                tag_card.setVisibility(View.GONE);
            }
        }
    }
}

