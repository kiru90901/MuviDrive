package com.inflix.android.utils.ytExtractor;

public interface LiveVideoInfoCallback {
    void onVideoUrlReceived(String videoStream);
    void onError(Exception e);
}
