package com.LiquidPager.liquid_swipe.animation

object Direction {
    val NONE = -1
    val LEFT = 0
    val RIGHT = 1
}